# Shafay'Thinking Starter Code

Frontend: Next.js + Tailwind
Backend: Express.js

Deploy frontend on Vercel and backend on Render.
